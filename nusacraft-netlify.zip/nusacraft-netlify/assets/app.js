(function () {
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // Menu mobile
  var btn = $('#menuBtn'), nav = $('#nav');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // Isi otomatis produk di formulir kontak (?product=...)
  var sel = $('select[name=product]');
  if (sel) {
    var m = location.search.match(/[?&]product=([^&]+)/);
    if (m) { try { sel.value = decodeURIComponent(m[1]); } catch (x) {} }
  }

  // Filter & pencarian katalog
  var grid = $('#grid');
  if (grid) {
    var q = $('#q'), chips = $$('#chips .chip'), empty = $('#empty'), cat = 'all';
    var apply = function () {
      var term = (q.value || '').trim().toLowerCase(), shown = 0;
      $$('.card', grid).forEach(function (c) {
        var ok = (cat === 'all' || c.dataset.cat === cat) && (!term || c.dataset.name.indexOf(term) > -1);
        c.hidden = !ok;
        if (ok) shown++;
      });
      empty.hidden = shown > 0;
    };
    q.addEventListener('input', apply);
    chips.forEach(function (ch) {
      ch.addEventListener('click', function () {
        chips.forEach(function (x) { x.classList.remove('on'); });
        ch.classList.add('on');
        cat = ch.dataset.cat;
        apply();
      });
    });
  }

  // Popup detail produk
  var modal = $('#modal');
  if (modal && window.NC) {
    var i18n = NC.i18n, last = null;
    var close = function () { modal.hidden = true; document.body.style.overflow = ''; if (last) last.focus(); };
    var open = function (p, trigger) {
      last = trigger;
      $('#mImg').src = p.img;
      $('#mImg').alt = p.name;
      $('#mTitle').textContent = p.name;
      $('#mDesc').textContent = p.desc;
      var dl = $('#mSpec');
      dl.innerHTML = '';
      [[i18n.material, p.material], [i18n.size, p.size], [i18n.moq, p.moq + ' ' + i18n.pcs]].forEach(function (row) {
        var dt = document.createElement('dt'), dd = document.createElement('dd');
        dt.textContent = row[0]; dd.textContent = row[1];
        dl.appendChild(dt); dl.appendChild(dd);
      });
      $('#mQuote').href = NC.quote + '?product=' + encodeURIComponent(p.id);
      modal.hidden = false;
      document.body.style.overflow = 'hidden';
      $('#mClose').focus();
    };
    document.addEventListener('click', function (ev) {
      var card = ev.target.closest && ev.target.closest('.card');
      if (card && (ev.target.closest('.detail-btn') || ev.target.tagName === 'IMG')) {
        open(JSON.parse(card.dataset.product), ev.target.closest('.detail-btn') || card.querySelector('.detail-btn'));
      }
    });
    $('#mClose').addEventListener('click', close);
    modal.addEventListener('click', function (ev) { if (ev.target === modal) close(); });
    document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && !modal.hidden) close(); });
  }
})();
